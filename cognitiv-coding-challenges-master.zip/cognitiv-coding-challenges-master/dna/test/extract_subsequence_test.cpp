#include "catch.hpp"
#include "fake_person.hpp"
#include "extract_subsequence.cpp"
#include <iostream>

TEST_CASE("Extracting sub-sequence from a fake person's DNA", "[extract_subsequence]")
{
    std::array<std::vector<std::byte>, 23> dna_data;

    //To make the test cases simple and also to know the subsequence for testing, keeping the chromosome data simple.
    for (std::size_t i = 0; i < dna_data.size(); ++i)
    {
        dna_data[i] = {static_cast<std::byte>('A'), static_cast<std::byte>('C'), static_cast<std::byte>('T'), static_cast<std::byte>('G')};
    }

    fake_person person(dna_data, 4);

    SECTION("Extracting sub-sequence from middle of first chromosome")
    {
        // Extract a sub-sequence from the middle of the first chromosome
        auto subseq = extract_subsequence(person, 1, 3);

        // Check that the sub-sequence has the expected data
        REQUIRE(subseq == "CT");
    }

    SECTION("Extracting sub-sequence from end of first chromosome")
    {
        // Extract a sub-sequence from the end of the first chromosome
        auto subseq = extract_subsequence(person, 20, 22);

        // Check that the sub-sequence has the expected data
        REQUIRE(subseq == "AC");
    }

    SECTION("Extracting sub-sequence from invalid range, throws out of range exception")
    {
        // Extract a sub-sequence with an invalid range
        REQUIRE_THROWS_AS(extract_subsequence(person, 1, 24), std::out_of_range);
    }
}