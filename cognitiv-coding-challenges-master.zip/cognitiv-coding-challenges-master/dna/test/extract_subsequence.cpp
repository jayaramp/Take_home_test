#include "fake_person.hpp"
#include <iostream>
#include <sstream>

/**
 * Function to extract subsequence of a chromosome from a person given start and length
 * @param stream
 * @param start
 * @param length
 * @return
 */
std::string extract_subsequence(fake_person& person, std::size_t start, std::size_t end)
{
    std::string subseq;

    // Validate start and end indices
    if (start > person.chromosomes() || end > person.chromosomes())
        throw std::out_of_range("index out of range");

    // Find the chromosome that contains the start of the sub-sequence
    std::size_t chromosome_index = start / person.chromosome(0).size();
    std::size_t chromosome_position = start % person.chromosome(0).size();

    // Read data from the chromosome until the end of the sub-sequence is reached
    while (subseq.size() < end - start)
    {
        std::size_t count = end - start - subseq.size();
        if (count < 0)
            count = 0;

        auto data = person.chromosome(chromosome_index).data();

        // Append the data to the sub-sequence using a stringstream
        std::stringstream ss;
        ss.write(reinterpret_cast<const char*>(data.data() + chromosome_position), count);
        subseq += ss.str();

        // Move to the next chromosome
        ++chromosome_index;
        chromosome_position = 0;
    }

    return subseq;
}
