#include "fake_person.hpp"
#include <iostream>

/**
 * This is a helper function for compare_chromosomes
 * @param stream1
 * @param stream2
 * @return
 */
std::vector<std::pair<std::size_t, char>> compare_streams(fake_stream stream1, fake_stream stream2)
{
    std::vector<std::pair<std::size_t, char>> differences;

    // Read data from both streams
    std::string data1, data2;

    //Reading character by character from the buffer since somehow string read had some issues.
    auto buffer = stream1.read();
    while (buffer.size() > 0) {
        for (const auto& base : buffer) {
            data1 += static_cast<char>(base);
        }
        buffer = stream1.read();
    }

    buffer = stream2.read();
    while (buffer.size() > 0) {
        for (const auto& base : buffer) {
            data2 += static_cast<char>(base);
        }
        buffer = stream2.read();
    }

    // Compare the data and build the differences
    for (std::size_t i = 0; i < data1.size(); ++i)
    {
        if (data1[i] != data2[i])
            differences.push_back({i, data1[i]});
    }

    return differences;
}

/**
 * Function to compare the chromosomes of two persons and return a collection
 * highlighting the interesting distinctions between the two people.
 * @param person1
 * @param person2
 * @return
 */
std::vector<std::pair<std::size_t, char>> compare_chromosomes(fake_person& person1, fake_person& person2)
{
    std::vector<std::pair<std::size_t, char>> distinct_chromosomes;

    // Compare the number of chromosomes to check between two persons
    if (person1.chromosomes() != person2.chromosomes())
    {
        //Return empty distinct_chromosomes collection
        return distinct_chromosomes;
    }

    for (std::size_t i = 0; i < person1.chromosomes(); ++i)
    {
        // Compare the two chromosomes
        auto difference_stream = compare_streams(person1.chromosome(i), person2.chromosome(i));

        // Add the differences to the overall collection of distinct_chromosomes
        for (const auto& difference : difference_stream)
        {
            distinct_chromosomes.push_back({difference.first + i * person1.chromosome(i).size(), difference.second});
        }
    }

    return distinct_chromosomes;
}