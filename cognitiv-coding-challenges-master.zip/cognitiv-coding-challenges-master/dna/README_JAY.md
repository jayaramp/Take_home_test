# Compile and Building this Project

Go to: cognitiv-coding-challenges-master -> dna

`cmake .`

`make all`

`./test/dna_test`

# APIs
## compare_chromosomes

`compare_chromosomes` is a function that takes two fake_person objects as input and returns a vector of pairs. 
Each pair contains the position of a difference in the DNA sequence and the value at that position for one of 
the fake_person objects.

The function first checks if the number of chromosomes for the two fake_person objects is the same. 
If not, it returns an empty vector.

If the number of chromosomes is the same, the function compares the DNA sequence for each pair of chromosomes 
using the `compare_streams` function. It then adds the differences to the overall collection of distinct chromosomes 
and returns the collection at the end.

`std::vector<std::pair<std::size_t, char>> compare_chromosomes(fake_person& person1, fake_person& person2)`

### source file
test/compare_chromosomes.cpp

### test file
test/compare_chromosomes_test.cpp

## extract_subsequence

The `extract_subsequence` function extracts a sub-sequence from a DNA sequence represented by a fake_person object. 
The function takes as input a reference to the fake_person object, and the start and end positions of the sub-sequence 
within the DNA sequence.

The function first determines the chromosome and position within the chromosome that contains the start of the sub-sequence. 
It then reads data from the chromosome until the end of the sub-sequence is reached, appending the data to a `std::string` 
object called `subseq`. The function returns the subseq string when it is finished.

`std::string extract_subsequence(fake_person& person, std::size_t start, std::size_t end)`

### source file
test/extract_subsequence.cpp

### test file
test/extract_subsequence_test.cpp

*All the source files and test cases have enough comments to understand better.
